*************************************
Thank you for purchasing our template
*************************************

FILES
-----
Fuse-v8.1.2-demo.zip     : Fuse Template Demo Project
Fuse-v8.1.2-skeleton.zip : Fuse Template Skeleton Project


UPDATING THE TEMPLATE
---------------------
You can use the GitHub repository to easily update the template.
To access the repository visit: http://withinpixels.com/themes/fuse-github


DOCUMENTATION
-------------
You can access the online documentation at
http://angular-material.fusetheme.com/documentation/getting-started/introduction


SUPPORT REQUESTS
----------------
For your support requests, please visit http://withinpixels.ticksy.com
Your support requests will be queued and can take up to 48 hours in
working days before answered.